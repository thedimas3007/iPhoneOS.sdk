//
//  ILBase.h
//  IdentityLookup
//
//  Copyright © 2017 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#ifdef __cplusplus
#define IL_EXTERN extern "C" __attribute__((visibility("default")))
#else
#define IL_EXTERN extern __attribute__((visibility("default")))
#endif

NS_ASSUME_NONNULL_END
